#ifndef __VERSION_H__
#define __VERSION_H__

#define VERSION_MAJOR   5
#define VERSION_MINOR   51
#define VERSION_PATCH   1

#define DRIVER_VERSION_STR STR(VERSION_MAJOR) "." STR(VERSION_MINOR) "." STR(VERSION_PATCH)

#define DRIVER_NAME     "cryptoserver"

#define DRIVER_BUILD          ""

#ifdef TRACE
#undef DRIVER_BUILD
#define DRIVER_BUILD          "[TRACE]"
#endif

#ifdef DEBUG
#undef DRIVER_BUILD
#define DRIVER_BUILD          "[DEBUG]"
#endif

#endif
