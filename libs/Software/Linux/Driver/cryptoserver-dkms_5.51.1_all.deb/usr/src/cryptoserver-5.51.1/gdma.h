/* SPDX-License-Identifier: GPL-2.0-only
 *
 * Copyright 2025 Utimaco IS GmbH
 * All Rights Reserved.
 *
 */
#ifndef __GDMA_H__
#define __GDMA_H__

#define GDMA_MAX_CHANNELS             32

#define GDMA_DESC_SIZE                16
#define GDMA_QUEUE_SIZE               64
#define GDMA_QUEUE_OFFSET             (GDMA_QUEUE_SIZE * GDMA_DESC_SIZE)

#define GDMA_SRC_Q_BASE               0
#define GDMA_SRC_Q_ADDR(idx)          (GDMA_SRC_Q_BASE + ((idx) << 4))  // * 16

#define GDMA_DST_Q_BASE               GDMA_QUEUE_OFFSET
#define GDMA_DST_Q_ADDR(idx)          (GDMA_DST_Q_BASE + ((idx) << 4))

#define GDMA_REG_BASE                 (2 * GDMA_QUEUE_OFFSET)   // 0x800

// Index_ptr
#define GDMA_SRC_Q_RD_IDX             (GDMA_REG_BASE       )
#define GDMA_SRC_Q_WR_IDX             (GDMA_REG_BASE + 0x01)
#define GDMA_DST_Q_RD_IDX             (GDMA_REG_BASE + 0x02)
#define GDMA_DST_Q_WR_IDX             (GDMA_REG_BASE + 0x03)

// Irq
#define GDMA_IRQ_MASK                 (GDMA_REG_BASE + 0x08)
#define GDMA_IRQ_ENABLE               (GDMA_REG_BASE + 0x09)
#define GDMA_IRQ_STATUS               (GDMA_REG_BASE + 0x0A)
#define GDMA_IRQ_TEST                 (GDMA_REG_BASE + 0x0B)

#define GDMA_IRQ_DMA_TX               1
#define GDMA_IRQ_DMA_RX               2
#define GDMA_IRQ_MAILBOX              4

// Control
#define GDMA_CONTROL                  (GDMA_REG_BASE + 0x0C)

#define GDMA_CONTROL_CHNL_RESET       1
#define GDMA_CONTROL_LOOPBACK         2
#define GDMA_CONTROL_SRIO_DISABLE     4       // host only
#define GDMA_CONTROL_BLOCK_RESET      0x100
#define GDMA_CONTROL_RESET_PS         0x10000 // SWRE host only
#define GDMA_CONTROL_RESET_SYS        0x20000 // SYRE host only

// gmtime
#define GDMA_TIMESTAMP                (GDMA_REG_BASE + 0x10)

// version
#define GDMA_VERSION                  (GDMA_REG_BASE + 0x14)

// Mailbox
#define GDMA_MAILBOX_IN               (GDMA_REG_BASE + 0x18)
#define GDMA_MAILBOX_OUT              (GDMA_REG_BASE + 0x1C)

// Version
#define GDMA_FPGA_VERSION             (GDMA_REG_BASE + 0x20)
#define GDMA_HW_VERSION               (GDMA_REG_BASE + 0x24)

// Debug
#define GDMA_DEBUG                    (GDMA_REG_BASE + 0x28)

#define GDMA_DEBUG_MRXP               0x00800000
#define GDMA_DEBUG_MRXC_MASK          0x00700000
#define GDMA_DEBUG_MRXS               0x00080000
#define GDMA_DEBUG_REAE               0x00040000
#define GDMA_DEBUG_REFS_MASK          0x00030000
#define GDMA_DEBUG_DMFI_MASK          0x0000C000
#define GDMA_DEBUG_DMAL               0x00002000
#define GDMA_DEBUG_DMAT               0x00001000
#define GDMA_DEBUG_DMAE_MASK          0x00000F00
#define GDMA_DEBUG_NFAE               0x00000080
#define GDMA_DEBUG_FATE               0x00000040
#define GDMA_DEBUG_CORE               0x00000020
#define GDMA_DEBUG_LOER_MASK          0x0000001F

// Error_counter
#define GDMA_ERROR_COUNT              (GDMA_REG_BASE + 0x2C)

#define GDMA_ERROR_BITE_MASK          0x0000FFFF
#define GDMA_ERROR_BITE_SHIFT         0
#define GDMA_ERROR_DISP_MASK          0xFFFF0000
#define GDMA_ERROR_DISP_SHIFT         16

// Irq_queue (new)
#define GDMA_IRQ_QUEUE_SRC            (GDMA_REG_BASE + 0x30)
#define GDMA_IRQ_QUEUE_DST            (GDMA_REG_BASE + 0x38)
#define GDMA_IRQ_QUEUE_MAILBOX        (GDMA_REG_BASE + 0x40)

#define GDMA_IRQ_CHNU_MASK            0x0000001F
#define GDMA_IRQ_CHNU_SHIFT           0
#define GDMA_IRQ_QLEL_MASK            0x00FF0000
#define GDMA_IRQ_QLEL_SHIFT           16

// Core_Control (moved as of 7.3.2)
#define GDMA_CORE_CONTROL             (GDMA_REG_BASE + 0x48)

#define GDMA_CTL_MAXREAD_128_MASK     0x000F
#define GDMA_CTL_MAXREAD_128_SHIFT    0
#define GDMA_CTL_MAXREAD_256_MASK     0x00F0
#define GDMA_CTL_MAXREAD_256_SHIFT    4
#define GDMA_CTL_MAXREAD_512_MASK     0x0F00
#define GDMA_CTL_MAXREAD_512_SHIFT    8
#define GDMA_CTL_MAXREAD_1024_MASK    0xF000
#define GDMA_CTL_MAXREAD_1024_SHIFT   12
#define GDMA_CTL_ALWAYS_IRQ           0x10000

// Serial nummber
#define GDMA_SSN_LOW                  (GDMA_REG_BASE + 0x50)
#define GDMA_SSN_HIGH                 (GDMA_REG_BASE + 0x54)

// MSI-X Vector Table
#define GDMA_MSIX_IRQ_ADDR_SRC_LOW    (GDMA_REG_BASE + 0x80)
#define GDMA_MSIX_IRQ_ADDR_SRC_HIGH   (GDMA_REG_BASE + 0x84)
#define GDMA_MSIX_IRQ_DATA_SRC        (GDMA_REG_BASE + 0x88)
#define GDMA_MSIX_IRQ_MASK_SRC        (GDMA_REG_BASE + 0x8C)

#define GDMA_MSIX_IRQ_ADDR_DST_LOW    (GDMA_REG_BASE + 0x90)
#define GDMA_MSIX_IRQ_ADDR_DST_HIGH   (GDMA_REG_BASE + 0x94)
#define GDMA_MSIX_IRQ_DATA_DST        (GDMA_REG_BASE + 0x98)
#define GDMA_MSIX_IRQ_MASK_DST        (GDMA_REG_BASE + 0x9C)

#define GDMA_MSIX_IRQ_ADDR_MAIL_LOW   (GDMA_REG_BASE + 0xA0)
#define GDMA_MSIX_IRQ_ADDR_MAIL_HIGH  (GDMA_REG_BASE + 0xA4)
#define GDMA_MSIX_IRQ_DATA_MAIL       (GDMA_REG_BASE + 0xA8)
#define GDMA_MSIX_IRQ_MASK_MAIL       (GDMA_REG_BASE + 0xAC)


union packet_info_t
{
  // TODO: endianess
  struct
  {
    union
    {
      struct
      {
        u8  seq_cnt : 7;
        u8  last    : 1;
        u8  msg_idx;
        u8  addr;
        u8  rfu;
      };

      u32   user;
    };

    u16 wlen;
    u16 pid;
  };

  u64 value;
}
#ifndef _WIN64
__attribute__((__packed__))
#endif
;

struct q_desc_t
{
  u64                 phys_addr;
  union packet_info_t info;
}
#ifndef _WIN64
__attribute__((__packed__))
#endif
;

#endif
